# -*- coding: utf-8 -*-
"""
gen_tree.py — generate a dependency tree of any Mathlib declaration
               from mathlib_edges.csv, annotating each node with its
               class ([def], [thm], or [ax]) and (exact or heuristic)
               source file path in Mathlib.

Output format (per node, two lines):

    <prefix><branch> <name>  [<class>]   <marker>
    <prefix>@ <path>

`<prefix>` is the ancestor continuation string (e.g. "|   "), the
same on both lines so the `@ PATH` sits directly under the branch
marker.  ASCII only — safe to paste into a LaTeX verbatim block.

Class labels:
    [def] = definition / typeclass instance
    [thm] = theorem / lemma
    [ax]  = Lean kernel axiom (propext, funext, Quot.sound,
            Classical.choice) or a name reached through one

Filters:
    --only-thms   keep [thm] AND [ax] nodes (axioms are part of the
                  logical foundation, so they are kept by default)
    --only-defs   keep only [def] nodes
    --no-axioms   drop [ax] nodes from the output (compose with
                  --only-thms to get a pure theorem skeleton)

Path resolution order (first hit wins):
  1. exact match in the name->file map extracted from mathlib_edges.csv
  2. exact match in a --paths CSV (name,file)
  3. longest-prefix match in the --paths CSV
  4. longest-prefix match in the built-in NAMESPACE_PATHS table
  5. if the name has no dot -> "Lean core (not in Mathlib)"
  6. fallback: "Mathlib/**/<top>/**"

Default locations (override with the CLI flags):
    CSV     : E:\\archives\\Processings\\MathsTools\\mathlib_tree\\mathlib_edges.csv
    Python  : D:\\Python38\\python.exe   (used by run.bat)

Usage:
    python gen_tree.py <theorem_name> [--depth N] [--out FILE] [--csv FILE]
                                      [--paths FILE] [--max-nodes N]
                                      [--leaf-marker STR] [--no-dedup]
                                      [--only-thms | --only-defs]
                                      [--no-axioms]
                                      [--no-classify] [--no-paths]
"""
import sys
import os
import re
import argparse
from collections import defaultdict

# ---------- default locations ----------
DEFAULT_CSV = r"E:\archives\Processings\MathsTools\mathlib_tree\mathlib_edges.csv"

# ---------- parse arguments ----------
parser = argparse.ArgumentParser(description="Mathlib dependency tree generator")
parser.add_argument("target", help="name of the theorem / declaration")
parser.add_argument("--depth", type=int, default=2,
                    help="max recursion depth (default: 2); 0 means unlimited")
parser.add_argument("--out", type=str, default=None,
                    help="output .txt file (default: <target>.tree.txt)")
parser.add_argument("--csv", type=str, default=DEFAULT_CSV,
                    help=f"path to mathlib_edges.csv (default: {DEFAULT_CSV})")
parser.add_argument("--paths", type=str, default=None,
                    help="optional CSV with name,file columns giving "
                         "declaration -> .lean file mapping")
parser.add_argument("--max-nodes", type=int, default=200000,
                    help="hard cap on the number of nodes actually "
                         "expanded (default 200000). Remaining nodes are "
                         "emitted as stubs marked (node budget).")
parser.add_argument("--leaf-marker", type=str, default="(depth limit)",
                    help='marker appended to terminal nodes '
                         '(default: "(depth limit)"; use "" to suppress)')
parser.add_argument("--no-dedup", action="store_true",
                    help="expand every path in full instead of skipping "
                         "subtrees already shown elsewhere")
parser.add_argument("--no-classify", action="store_true",
                    help="do not annotate nodes with [def]/[thm]/[ax]")
parser.add_argument("--no-paths", action="store_true",
                    help="do not annotate nodes with their .lean file path")
group = parser.add_mutually_exclusive_group()
group.add_argument("--only-thms", action="store_true",
                   help="keep [thm] and [ax] nodes; prune [def] subtrees")
group.add_argument("--only-defs", action="store_true",
                   help="keep only [def] nodes; prune [thm]/[ax] subtrees")
parser.add_argument("--no-axioms", action="store_true",
                    help="drop [ax] nodes from the output "
                         "(compose with --only-thms for a pure theorem tree)")
args = parser.parse_args()

TARGET = args.target
MAX_DEPTH = None if args.depth <= 0 else args.depth
UNLIMITED = MAX_DEPTH is None
MAX_NODES = None if args.max_nodes <= 0 else args.max_nodes
OUT_FILE = args.out or (TARGET.replace(".", "_") + ".tree.txt")
CSV_FILE = args.csv
PATHS_FILE = args.paths
CLASSIFY = not args.no_classify
SHOW_PATHS = not args.no_paths
ONLY_THMS = args.only_thms
ONLY_DEFS = args.only_defs
NO_AXIOMS = args.no_axioms
LEAF_MARKER = args.leaf_marker
DEDUP = not args.no_dedup

if not os.path.isfile(CSV_FILE):
    sys.exit(f"ERROR: CSV not found: {CSV_FILE}")

# ---------- column-name synonyms ----------
SRC_KEYS  = ("source", "src", "from", "decl", "declaration", "name",
             "theorem", "node", "u", "parent")
TGT_KEYS  = ("target", "tgt", "to", "dest", "dependency", "dep",
             "uses", "v", "child")
KIND_KEYS = ("kind", "class", "decl_kind", "declaration_kind",
             "node_kind", "decltype", "decl_type", "is_def")
FILE_KEYS = ("file", "path", "file_path", "filename", "source_file",
             "target_file", "src_file", "tgt_file", "mathlib_file",
             "decl_file", "declaration_file", "location", "src_path",
             "tgt_path", "source_path", "target_path")

# ---------- Lean kernel axioms ----------
# These four names are the primitive axioms of Lean 4's kernel.
#   propext          : (a <-> b) -> a = b
#   Quot.sound       : r a b -> Quot.mk r a = Quot.mk r b
#   Classical.choice : Nonempty a -> a
#   funext           : (forall x, f x = g x) -> f = g
# Mathlib conventionally lists all four when reporting #print axioms.
LEAN_AXIOMS = {
    "propext",
    "Quot.sound",
    "Classical.choice",
    "funext",
    # Alternate spellings that occasionally appear in CSVs
    "quot.sound",
    "classical.choice",
    "proof_irrel_heq",
    "Classical.propComplete",
}

# ---------- built-in heuristic namespace -> directory table ----------
NAMESPACE_PATHS = {
    "DifferentiableAt":             "Mathlib/Analysis/Calculus/Deriv/Basic.lean",
    "Differentiable":               "Mathlib/Analysis/Calculus/FDeriv/Basic.lean",
    "HasDerivAt":                   "Mathlib/Analysis/Calculus/Deriv/Basic.lean",
    "HasFDerivAt":                  "Mathlib/Analysis/Calculus/FDeriv/Basic.lean",
    "deriv":                        "Mathlib/Analysis/Calculus/Deriv/Basic.lean",
    "fderiv":                       "Mathlib/Analysis/Calculus/FDeriv/Basic.lean",
    "RCLike":                       "Mathlib/Analysis/RCLike/Basic.lean",
    "InnerProductSpace":            "Mathlib/Analysis/InnerProductSpace/Basic.lean",
    "ContinuousLinearMap":          "Mathlib/Topology/Algebra/Module/LinearMap.lean",
    "Continuous":                   "Mathlib/Topology/Defs/Basic.lean",
    "IsBoundedSMul":                "Mathlib/Analysis/NormedSpace/Basic.lean",
    "NormedAlgebra":                "Mathlib/Analysis/Normed/Algebra/Basic.lean",
    "intervalIntegral":             "Mathlib/MeasureTheory/Integral/IntervalIntegral/Basic.lean",
    "IntervalIntegrable":           "Mathlib/MeasureTheory/Integral/IntervalIntegral/Basic.lean",
    "MeasureTheory.MeasureSpace.volume":
                                    "Mathlib/MeasureTheory/MeasureSpace/Volume.lean",
    "MeasureTheory.MeasureSpace":   "Mathlib/MeasureTheory/MeasureSpace/Defs.lean",
    "MeasureTheory.Measure":        "Mathlib/MeasureTheory/Measure/Basic.lean",
    "MeasureTheory.IntegrableOn":   "Mathlib/MeasureTheory/Integral/OnFunctions.lean",
    "MeasureTheory.integral":       "Mathlib/MeasureTheory/Integral/Bochner/Basic.lean",
    "MeasureTheory":                "Mathlib/MeasureTheory",
    "Set.uIcc":                     "Mathlib/Data/Set/Intervals/UnorderedInterval.lean",
    "Set.Icc":                      "Mathlib/Data/Set/Intervals/Basic.lean",
    "Set.Ioo":                      "Mathlib/Data/Set/Intervals/Basic.lean",
    "Set.Ioc":                      "Mathlib/Data/Set/Intervals/Basic.lean",
    "Set.mem_Icc_of_Ioo":           "Mathlib/Data/Set/Intervals/Basic.lean",
    "Set.instMembership":           "Mathlib/Data/Set/Basic.lean",
    "Set.Mem":                      "Mathlib/Data/Set/Basic.lean",
    "Set":                          "Mathlib/Data/Set",
    "Real":                         "Mathlib/Data/Real/Basic.lean",
    "Nat":                          "Mathlib/Data/Nat",
    "Int":                          "Mathlib/Data/Int",
    "List":                         "Mathlib/Data/List",
    "Polynomial":                   "Mathlib/Algebra/Polynomial",
    "PseudoMetricSpace":            "Mathlib/Topology/MetricSpace/PseudoMetricSpace.lean",
    "UniformSpace":                 "Mathlib/Topology/UniformSpace/Basic.lean",
    "Bornology":                    "Mathlib/Topology/Bornology/Basic.lean",
    "CompleteSpace":                "Mathlib/Topology/Algebra/UniformGroup.lean",
    "TopologicalSpace":             "Mathlib/Topology/Defs/Basic.lean",
    "NormedAddCommGroup":           "Mathlib/Analysis/Normed/Group/Basic.lean",
    "NormedAddGroup":               "Mathlib/Analysis/Normed/Group/Basic.lean",
    "NormedCommRing":               "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "NormedRing":                   "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "NonUnitalNormedCommRing":      "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "NonUnitalNormedRing":          "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "SeminormedAddCommGroup":       "Mathlib/Analysis/Normed/Group/Basic.lean",
    "SeminormedRing":               "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "SeminormedCommRing":           "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "NonUnitalSeminormedCommRing":  "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "NonUnitalSeminormedRing":      "Mathlib/Analysis/Normed/Ring/Basic.lean",
    "DenselyNormedField":           "Mathlib/Analysis/Normed/Field/Basic.lean",
    "NontriviallyNormedField":      "Mathlib/Analysis/Normed/Field/Basic.lean",
    "NormedField":                  "Mathlib/Analysis/Normed/Field/Basic.lean",
    "NormedSpace":                  "Mathlib/Analysis/NormedSpace/Basic.lean",
    "dist":                         "Mathlib/Topology/MetricSpace/PseudoMetricSpace.lean",
    "Dist":                         "Mathlib/Topology/MetricSpace/PseudoMetricSpace.lean",
    "enorm":                        "Mathlib/Analysis/Normed/Group/Basic.lean",
    "intervalIntegrable_iff_integrableOn_Icc_of_le":
                                    "Mathlib/MeasureTheory/Integral/IntervalIntegral/Basic.lean",
    "AddGroup":                     "Mathlib/Algebra/Group/Defs.lean",
    "AddCommGroup":                 "Mathlib/Algebra/Group/Defs.lean",
    "AddMonoid":                    "Mathlib/Algebra/Group/Defs.lean",
    "AddZero":                      "Mathlib/Algebra/Group/Defs.lean",
    "AddZeroClass":                 "Mathlib/Algebra/Group/Defs.lean",
    "SubNegMonoid":                 "Mathlib/Algebra/Group/Defs.lean",
    "SubNegZeroMonoid":             "Mathlib/Algebra/Group/Defs.lean",
    "SubtractionCommMonoid":        "Mathlib/Algebra/Group/Defs.lean",
    "MonoidWithZero":               "Mathlib/Algebra/GroupWithZero/Defs.lean",
    "MulZeroClass":                 "Mathlib/Algebra/GroupWithZero/Defs.lean",
    "NegZeroClass":                 "Mathlib/Algebra/Group/Defs.lean",
    "Ring":                         "Mathlib/Algebra/Ring/Defs.lean",
    "CommRing":                     "Mathlib/Algebra/Ring/Defs.lean",
    "Semiring":                     "Mathlib/Algebra/Ring/Defs.lean",
    "Semifield":                    "Mathlib/Algebra/Field/Defs.lean",
    "DivisionSemiring":             "Mathlib/Algebra/Field/Defs.lean",
    "Field":                        "Mathlib/Algebra/Field/Defs.lean",
    "Module":                       "Mathlib/Algebra/Module/Defs.lean",
    "DistribMulAction":             "Mathlib/Algebra/Module/Defs.lean",
    "DistribSMul":                  "Mathlib/Algebra/Module/Defs.lean",
    "SMulZeroClass":                "Mathlib/Algebra/Module/Defs.lean",
    "Lattice":                      "Mathlib/Order/Lattice.lean",
    "DistribLattice":               "Mathlib/Order/Lattice.lean",
    "SemilatticeInf":               "Mathlib/Order/Lattice.lean",
    "SemilatticeSup":               "Mathlib/Order/Lattice.lean",
    "PartialOrder":                 "Mathlib/Order/Defs.lean",
    "Preorder":                     "Mathlib/Order/Defs.lean",
    "LinearOrder":                  "Mathlib/Order/Defs.lean",
    "HSub":                         "Mathlib/Algebra/Notation.lean",
    "instHSub":                     "Mathlib/Algebra/Notation.lean",
    "Subtype":                      "Mathlib/Data/Subtype/Basic.lean",
    "Zero":                         "Mathlib/Algebra/Group/Defs.lean",
    "OfNat":                        "Mathlib/Algebra/Group/Defs.lean",
}

LEAN_CORE = {
    "forall_congr", "implies_congr", "inferInstance", "outParam",
    "OfNat", "LE", "LT", "Max", "Min", "Membership", "Zero", "One",
    "HAdd", "HMul", "HPow", "HSub", "HDiv", "HMod", "HAnd", "HOr",
    "HXor", "HShiftLeft", "HShiftRight", "HAppend", "HEq", "HImp",
    "HIff", "HNot", "HSMul", "Decidable", "Nonempty", "PLift", "ULift",
    "Quot", "Quotient", "Classical", "Eq",
    "Subsingleton", "Inhabited", "Empty", "PUnit",
    "Unit", "Bool", "Option", "Sum", "Prod", "Sigma", "PSigma",
    "eq_self", "of_eq_true", "le_total",
    "min_comm", "min_eq_left", "min_eq_right",
    "sup_eq_left", "sup_eq_right",
}

# ---------- CSV helpers ----------
def _index_of(header_lower, keys, default=None):
    for i, c in enumerate(header_lower):
        if c in keys:
            return i
    return default

def _indices_of(header_lower, keys):
    return [i for i, c in enumerate(header_lower) if c in keys]

def load_paths_file(path):
    m = {}
    if not path or not os.path.isfile(path):
        return m
    with open(path, "r", encoding="utf-8") as f:
        first = f.readline().rstrip("\n")
        cols = [c.strip().lower() for c in first.split(",")]
        if "name" in cols and ("file" in cols or "path" in cols):
            name_idx = cols.index("name")
            file_idx = cols.index("file") if "file" in cols else cols.index("path")
        else:
            name_idx, file_idx = 0, 1
            parts = first.split(",")
            if len(parts) > 1:
                m[parts[0].strip()] = parts[1].strip()
        for line in f:
            parts = line.rstrip("\n").split(",")
            if len(parts) <= max(name_idx, file_idx):
                continue
            m[parts[name_idx].strip()] = parts[file_idx].strip()
    return m

# ---------- load edges ----------
print(f"Loading edges from {CSV_FILE} ...")
adj = defaultdict(list)
known_nodes = set()
kind_of = {}
csv_paths = {}

with open(CSV_FILE, "r", encoding="utf-8") as f:
    header_line = f.readline().rstrip("\n")
    header_cols = [c.strip() for c in header_line.split(",")]
    header_lower = [c.lower() for c in header_cols]

    src_idx  = _index_of(header_lower, SRC_KEYS, 0)
    tgt_idx  = _index_of(header_lower, TGT_KEYS, 1)
    kind_idx = _index_of(header_lower, KIND_KEYS, None)
    file_idxs = _indices_of(header_lower, FILE_KEYS)

    print(f"  Header: {header_cols}")
    print(f"  -> source column: '{header_cols[src_idx]}' (index {src_idx})")
    print(f"  -> target column: '{header_cols[tgt_idx]}' (index {tgt_idx})")
    if kind_idx is not None:
        print(f"  -> kind column:   '{header_cols[kind_idx]}' (index {kind_idx})")
    else:
        print("  -> kind column:   not present (heuristic will be used)")
    if file_idxs:
        names = ", ".join(f"'{header_cols[i]}'" for i in file_idxs)
        print(f"  -> file columns:  {names}")
    else:
        print("  -> file columns:  none detected")

    for line in f:
        parts = line.rstrip("\n").split(",")
        if len(parts) <= max(src_idx, tgt_idx):
            continue
        src = parts[src_idx].strip()
        tgt = parts[tgt_idx].strip()
        adj[src].append(tgt)
        known_nodes.add(src)
        known_nodes.add(tgt)

        if kind_idx is not None and len(parts) > kind_idx:
            raw = parts[kind_idx].strip().lower()
            if raw in ("def", "definition", "abbrev", "instance", "structure"):
                kind_of[src] = "def"
            elif raw in ("thm", "theorem", "lemma", "prop", "proposition",
                         "corollary"):
                kind_of[src] = "thm"
            elif raw in ("ax", "axiom"):
                kind_of[src] = "ax"

        for fi in file_idxs:
            if len(parts) <= fi:
                continue
            val = parts[fi].strip()
            if not val:
                continue
            col_name = header_lower[fi]
            if "target" in col_name:
                csv_paths.setdefault(tgt, val)
            else:
                csv_paths.setdefault(src, val)

edges_total = sum(len(v) for v in adj.values())
print(f"  {len(adj):,} source nodes, {edges_total:,} edges")
print(f"  {len(kind_of):,} nodes carry kind info from CSV")
print(f"  {len(csv_paths):,} nodes carry exact file paths from CSV")

PATHS_MAP = load_paths_file(PATHS_FILE)
for k, v in PATHS_MAP.items():
    csv_paths[k] = v
if PATHS_MAP:
    print(f"  {len(PATHS_MAP):,} additional mappings loaded from {PATHS_FILE}")

if TARGET not in known_nodes:
    print(f"WARNING: '{TARGET}' not found in graph — tree may be empty.")

# ---------- path resolution ----------
def path_of(name):
    if name in csv_paths:
        return csv_paths[name]
    best = None
    for k in csv_paths:
        if name.startswith(k + ".") and (best is None or len(k) > len(best)):
            best = k
    if best is not None:
        return csv_paths[best]
    # axioms live in Lean core / Mathlib's Logic.lean
    if name in LEAN_AXIOMS:
        if name in ("Classical.choice", "classical.choice",
                    "Classical.propComplete"):
            return "Mathlib/Logic/Choice.lean (Lean core)"
        return "Mathlib/Logic/Basic.lean (Lean core)"
    best = None
    for k in NAMESPACE_PATHS:
        if (name == k or name.startswith(k + ".")) and \
           (best is None or len(k) > len(best)):
            best = k
    if best is not None:
        return NAMESPACE_PATHS[best]
    if "." in name:
        top = name.split(".", 1)[0]
        if top in NAMESPACE_PATHS:
            return NAMESPACE_PATHS[top]
    if "." not in name or name.split(".", 1)[0] in LEAN_CORE:
        return "Lean core (not in Mathlib)"
    return f"Mathlib/**/{name.split('.', 1)[0]}/**"

# ---------- classification ----------
_INHERITANCE_RE = re.compile(r"\.to[A-Z]")

def classify_heuristic(name):
    # axiom check comes first
    if name in LEAN_AXIOMS:
        return "ax"
    if not name:
        return "def"
    last = name.rsplit(".", 1)[-1]
    if last.startswith("inst") or ".inst" in name:
        return "def"
    if _INHERITANCE_RE.search(name):
        return "def"
    if last and last[0].isupper():
        return "def"
    if "_" in last:
        return "thm"
    return "def"

def node_kind(name):
    if name in kind_of:
        return kind_of[name]
    return classify_heuristic(name)

def tag(name):
    """Class tag only; the path is emitted on its own line."""
    if not CLASSIFY:
        return ""
    return f"  [{node_kind(name)}]"

def keep(name):
    """Return True if this node should be kept under the active filters."""
    k = node_kind(name)
    if NO_AXIOMS and k == "ax":
        return False
    if not (ONLY_THMS or ONLY_DEFS):
        return True
    if ONLY_THMS:
        # keep theorems AND axioms: axioms are the foundation of proofs
        return k in ("thm", "ax")
    if ONLY_DEFS:
        return k == "def"
    return True

# ---------- tree data structure ----------
class TNode:
    __slots__ = ("name", "children", "marker", "is_cycle")
    def __init__(self, name):
        self.name = name
        self.children = []
        self.marker = ""
        self.is_cycle = False

_nodes_created = 0  # respect --max-nodes

def build_tree(node, depth=0, visited=None, seen_on_path=None):
    global _nodes_created
    if visited is None:
        visited = set()
    if seen_on_path is None:
        seen_on_path = set()

    n = TNode(node)

    if node in seen_on_path:
        n.is_cycle = True
        return n
    if DEDUP and node in visited:
        n.marker = "(*)"
        return n

    if MAX_NODES is not None and _nodes_created >= MAX_NODES:
        n.marker = "(node budget)"
        return n
    _nodes_created += 1

    if DEDUP:
        visited.add(node)
    seen_on_path.add(node)

    if MAX_DEPTH is not None and depth >= MAX_DEPTH:
        n.marker = "(depth limit)"
        seen_on_path.discard(node)
        return n

    deps = adj.get(node, [])
    if not deps:
        n.marker = LEAF_MARKER if LEAF_MARKER else ""
        seen_on_path.discard(node)
        return n

    for dep in sorted(set(deps)):
        n.children.append(build_tree(dep, depth + 1, visited, seen_on_path))

    seen_on_path.discard(node)
    return n

def prune_tree(node):
    if not keep(node.name):
        return None
    new = TNode(node.name)
    new.marker = node.marker
    new.is_cycle = node.is_cycle
    for child in node.children:
        pc = prune_tree(child)
        if pc is not None:
            new.children.append(pc)
    return new

def render_struct(node, prefix="", is_root=True, is_last=True):
    """Two lines per node: declaration + tag, then `@ PATH`.

    The second line reuses the same ancestor `prefix` as the first
    so the `@` sits flush under the branch marker.
    """
    lines = []
    display = f"(cycle: {node.name})" if node.is_cycle else node.name

    # ---- name line ------------------------------------------------
    if is_root:
        name_line = display + tag(node.name)
    else:
        name_line = (prefix
                     + ("`-- " if is_last else "|-- ")
                     + display
                     + tag(node.name))
    if node.marker:
        name_line += f"   {node.marker}"
    lines.append(name_line)

    # ---- path line ------------------------------------------------
    if SHOW_PATHS:
        lines.append(prefix + "@ " + path_of(node.name))

    # ---- children -------------------------------------------------
    child_prefix = "" if is_root else prefix + ("    " if is_last else "|   ")
    n = len(node.children)
    for i, child in enumerate(node.children):
        lines.extend(render_struct(
            child, prefix=child_prefix, is_root=False,
            is_last=(i == n - 1)))
    return lines

def count_nodes(node):
    total = 1
    for c in node.children:
        total += count_nodes(c)
    return total

# ---------- main ----------
print(f"Generating dependency tree for: {TARGET}")
if UNLIMITED:
    print("  --depth 0 (unlimited expansion)")
if MAX_NODES is not None:
    print(f"  --max-nodes {MAX_NODES:,}")
if not DEDUP:
    print("  --no-dedup (subtrees re-expanded at every occurrence)")

root = build_tree(TARGET, depth=0)
raw_size = count_nodes(root)
budget_hit = MAX_NODES is not None and _nodes_created >= MAX_NODES
print(f"  raw tree nodes: {raw_size:,}")
if budget_hit:
    print(f"  WARNING: node budget ({MAX_NODES:,}) reached; tree was truncated.")

if not DEDUP and raw_size > 200_000:
    print(f"  WARNING: --no-dedup produced {raw_size:,} nodes; "
          f"the output file may be very large.")

if ONLY_THMS or ONLY_DEFS or NO_AXIOMS:
    pruned = prune_tree(root)
    if pruned is None:
        pruned = TNode(root.name)
        pruned.marker = "(filtered out: target does not match --only-* filter)"
    root = pruned

lines = render_struct(root)

n_def = sum(1 for ln in lines if "[def]" in ln)
n_thm = sum(1 for ln in lines if "[thm]" in ln)
n_ax  = sum(1 for ln in lines if "[ax]"  in ln)
n_leaf = sum(1 for ln in lines if LEAF_MARKER and LEAF_MARKER in ln)

header = [
    "=" * 60,
    f"Dependency tree for: {TARGET}",
    f"Source: {CSV_FILE}",
    f"Max depth: {'unlimited' if UNLIMITED else MAX_DEPTH}",
    "(*) = already expanded elsewhere in this tree",
]
if CLASSIFY:
    header.append("[def] = definition / typeclass instance")
    header.append("[thm] = theorem / lemma")
    header.append("[ax]  = Lean kernel axiom "
                  "(propext, funext, Quot.sound, Classical.choice)")
if SHOW_PATHS:
    if csv_paths:
        header.append("@ PATH = on the line below each declaration, "
                      "exact from mathlib_edges.csv (or --paths) "
                      "where available; heuristic otherwise")
    else:
        header.append("@ PATH = on the line below each declaration, "
                      "heuristic from namespace only "
                      "(no path columns in CSV, no --paths file)")
if LEAF_MARKER:
    header.append(f"{LEAF_MARKER} = node has no further dependencies "
                  f"in the CSV")
if not DEDUP:
    header.append("Dedup: disabled (subtrees re-expanded)")
if ONLY_THMS:
    header.append("Filter: --only-thms "
                  "(pruned [def] subtrees; [ax] retained)")
elif ONLY_DEFS:
    header.append("Filter: --only-defs (pruned [thm]/[ax] subtrees)")
if NO_AXIOMS:
    header.append("Filter: --no-axioms (dropped [ax] nodes)")
if MAX_NODES is not None:
    header.append(f"Node budget: {MAX_NODES:,}"
                  + ("  [HIT — output truncated]"
                     if budget_hit else ""))
header.append("=" * 60)
header.append("")

with open(OUT_FILE, "w", encoding="utf-8") as f:
    f.write("\n".join(header + lines))
    f.write("\n")

print(f"Done. Written to: {OUT_FILE}")
print(f"  {len(lines):,} lines")
if CLASSIFY:
    print(f"  {n_def:,} def, {n_thm:,} thm, {n_ax:,} ax")
if LEAF_MARKER:
    print(f"  {n_leaf:,} terminal nodes ({LEAF_MARKER})")