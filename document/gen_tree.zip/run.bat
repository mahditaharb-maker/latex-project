@echo off
REM ============================================================
REM  run.bat — generate a Mathlib dependency tree
REM
REM  Depth:
REM    --depth N    expand at most N levels (default 2)
REM    --depth 0    UNLIMITED: expand until no more edges remain
REM
REM  Class labels:
REM    [def]  definition / typeclass instance
REM    [thm]  theorem / lemma
REM    [ax]   Lean kernel axiom (propext, funext, Quot.sound,
REM           Classical.choice)
REM
REM  Filters:
REM    --only-thms   keep theorems AND axioms; prune [def] subtrees
REM    --only-defs   keep only definitions
REM    --no-axioms   drop [ax] nodes (compose with --only-thms)
REM
REM  Usage:
REM    run.bat <theorem_name> [--depth N] [--out FILE]
REM                           [--paths FILE] [--max-nodes N]
REM                           [--leaf-marker STR] [--no-dedup]
REM                           [--only-thms | --only-defs]
REM                           [--no-axioms]
REM                           [--no-classify] [--no-paths]
REM
REM  Examples:
REM    run.bat intervalIntegral.integral_deriv_eq_sub
REM    run.bat intervalIntegral.integral_deriv_eq_sub --depth 0 --only-thms
REM    run.bat intervalIntegral.integral_deriv_eq_sub --depth 5 --only-thms
REM    run.bat intervalIntegral.integral_deriv_eq_sub --depth 0 --only-thms --no-axioms
REM    run.bat intervalIntegral.integral_deriv_eq_sub --depth 0 --no-dedup --max-nodes 50000
REM ============================================================

setlocal enabledelayedexpansion

set PYTHON=D:\Python38\python.exe
set SCRIPT=%~dp0gen_tree.py
set CSV=%~dp0mathlib_edges.csv

if not exist "%PYTHON%" (
    echo ERROR: Python not found at %PYTHON%
    exit /b 1
)
if not exist "%SCRIPT%" (
    echo ERROR: gen_tree.py not found at %SCRIPT%
    exit /b 1
)
if not exist "%CSV%" (
    echo ERROR: mathlib_edges.csv not found at %CSV%
    exit /b 1
)
if "%~1"=="" (
    echo Usage: run.bat ^<theorem_name^> [--depth N] [--out FILE] [--paths FILE] [--max-nodes N] [--leaf-marker STR] [--no-dedup] [--only-thms^|--only-defs] [--no-axioms]
    echo Example: run.bat intervalIntegral.integral_deriv_eq_sub --depth 5 --only-thms
    exit /b 1
)

set ARGS=%*
set PREV=
for %%A in (%ARGS%) do (
    if "!PREV!"=="--paths" (
        if not exist "%%~A" (
            echo ERROR: --paths file not found: %%~A
            exit /b 1
        )
    )
    set PREV=%%A
)

"%PYTHON%" "%SCRIPT%" %* --csv "%CSV%"

set RC=%ERRORLEVEL%
endlocal & exit /b %RC%