@echo off
REM ============================================================
REM  find_edges.bat — search mathlib_edges.csv for a substring
REM
REM  Usage:
REM    find_edges.bat <substring> [output.txt]
REM
REM  Examples:
REM    find_edges.bat integral_sub_integral
REM    find_edges.bat integral_sub_integral ftc_root.txt
REM    find_edges.bat linear_isLittleO litto.txt
REM ============================================================

setlocal

set CSV=%~dp0mathlib_edges.csv

if not exist "%CSV%" (
    echo ERROR: mathlib_edges.csv not found at %CSV%
    exit /b 1
)

if "%~1"=="" (
    echo Usage: find_edges.bat ^<substring^> [output.txt]
    echo Example: find_edges.bat integral_sub_integral
    exit /b 1
)

if "%~2"=="" (
    set OUT=%~dp0find_edges_%~1.txt
) else (
    set OUT=%~dp0%~2
)

echo Searching for: %~1
echo Output file:    %OUT%
echo.

findstr /I "%~1" "%CSV%" > "%OUT%"

for /f %%C in ('find /c /v "" ^< "%OUT%"') do set COUNT=%%C

echo Done.
echo   matches: %COUNT%
echo   written to: %OUT%

endlocal